

public class Main {

    public static void main(String[] args) {
        System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t***********************************");
        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|         CGPA Calculator         |");
        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t***********************************");

        Input i1=new Input();

        System.out.println();

        i1.semesterNo();

    }


}

