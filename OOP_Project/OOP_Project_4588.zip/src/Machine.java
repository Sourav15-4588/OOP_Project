public interface Machine {
    void inputAll(int a);
    void semesterNo();
    void display();
    double Calculation(double a, double b);
    String remarks(double a);

}
